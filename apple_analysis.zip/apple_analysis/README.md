# Apple experiment: analysis code

Question: does a healthy apple's signal change when a rotten apple is added next to it,
compared with adding a healthy apple? Three channels run in parallel (dummy, control, test),
48 h before and 48 h after the neighbour is added.

## Files
- `analyze_apples.py`: the analysis.
- `make_demo_data.py`: makes fake data in the server's format, to try the analysis first. It can also add a sudden jump on one channel, a warmer test bag, several sites, and writes example climate, event and weight files.
- `pilot_compare.py`: compares several sensors band by band (used on Peter's pilot recordings, which have no before/after).
- `power_sim.py`: how many runs do we need? Smallest effect the main test can find with 2 to 8 runs.
- Templates (example values only): `design_example.csv`, `events_example.csv`, `climate_example.csv`, `weights_example.csv`.

## Set up
```
pip install numpy scipy pandas matplotlib
```

## Try it with fake data
```
python make_demo_data.py --out demo_data --runs 3 --hours 6 --fs 100
python analyze_apples.py --data demo_data --design demo_data/design.csv --out demo_results
```
The fake test channel gets a real effect of 1.5x amplitude (about 2.25x power, 0.35 in log10).
The report should show a difference near +0.35. Use `--effect 1.0` for no effect, or
`--effect-band 10 20` to put the effect in one frequency band only and see the sweep pick it out.
(Use at least 6 hours per phase for the demo: the script skips 2 h after the start and 1 h around the event.)

## Use it on the real data
1. Copy the server's data folder (`<device>/<device>_<UTC>_<epoch>.wav`) to your computer.
2. Copy `design_example.csv` to `design.csv` and fill in one row per run and device:
   - `condition` is `dummy`, `control` or `test`
   - `sensor_type` is `biolingo` or `breadboard`
   - times are UTC. Cologne winter time is UTC+1, so 15:00 in Cologne is `14:00:00Z`.
     `end_utc` is optional (default: as long after as before).
3. Optional files (each one adds a section to the report; see the `*_example.csv` templates):
   - `events.csv`: columns `time` (UTC) and `note`, every bag opening or touch. Bins near an event are left out,
     and the notes explain jumps in the signal.
   - `climate.csv`: columns `time` (UTC), `sensor`, `temp_c`, `humidity`. `sensor` is the logger of a bag (column
     `logger` in the design file, default = the device name) or `room`. Hourly is enough. Used as control variables.
   - `weights.csv`: columns `run`, `role`, `weight_start_g`, `weight_end_g`: weight loss per apple.
   - In the design file, an optional `site` column (for example `germany`, `switzerland`) shows results per site and
     controls for the site.
4. Run:
```
python analyze_apples.py --data path/to/data --design design.csv --events events.csv --climate climate.csv --weights weights.csv --out results
```

## What you get
- `report.txt`: the primary test (with automatic warnings), robustness checks, the exploratory band, the frequency sweep,
  sudden jumps, results per site, temperature and humidity, weight loss and the regression (sensor type, site, climate)
- `jumps.csv`: every sudden level change in the primary band, whether the dummy saw it too and whether an event explains it
- `sweep.csv` and `sweep.png`: the exploratory frequency sweep (below)
- `dropped.csv` (and a section in `report.txt`): for every run and channel, how many 5-minute bins were expected,
  never recorded, dropped for gaps, dropped for saturation, left out on purpose, and actually used
- `spectrogram_run_<id>.png`: every frequency over time for the dummy, control and test channels of a run
- `runs_summary.csv`: one row per run
- `windows.csv`: every 5-minute bin (flags show dropped bins)
- `run_<id>.png` and `summary.png`: plots

## How to read it
- **Nothing is deleted.** The code reads every sample, but the statistics use one number per frequency band per
  5-minute bin. Short bursts and the exact shape of the signal are not captured by band power, so look at the
  spectrograms (white = dropped or missing; the dashed line is when the neighbour was added) as well as the tests.
- Effects are on log10 band power, apple minus dummy. 0.30 is about 2x the power.
- **Primary (confirmatory) test:** change(test) minus change(control), per run, then a one-sample
  t-test across runs. The band (5-20 Hz) and the test are fixed at the top of the script.
  Change them before recording, never after.
- Everything else (2-5 Hz band, the frequency sweep, robustness, regression) is exploratory.
- **Frequency sweep:** the boards sample at 400 Hz. The repo firmware saves 400 Hz files, but Peter's email says 100 Hz, so check `sample_rate` in a test file. The sweep uses whatever bands the files allow (up to 45 Hz for 100 Hz files).
  The sweep repeats the same steps for 0.5-1, 1-2, 2-5, 5-10, 10-20, 20-45 and (400 Hz data only)
  55-95 Hz, plus three slow bands (0.01-0.03, 0.03-0.1, 0.1-0.5 Hz). `p_holm` corrects for looking at many bands, so a lucky band does not look significant.
  Edit `SLOW_BANDS` / `FAST_BANDS` at the top of the script to change the list. The sweep never replaces the primary test.
- **Slow bands (below 0.5 Hz), added after Peter's feedback.** They use a separate path: no high-pass
  (a 0.5 Hz high-pass would delete them) and long Welch segments (`--slow-segment-s`, default 150 s, so
  3 segments per 5-minute bin; the lowest usable frequency is about 2 / that value, so about 0.013 Hz).
  The 0.01-0.03 Hz band contains Peter's "one change every 44 seconds" (0.023 Hz). Check the dummy channel
  and the temperature/humidity logs before believing a slow-band result, because slow drifts in
  temperature or electrode gel look like slow signals. Also check that the board itself lets these
  frequencies through (the AD8232 chip has a high-pass filter in many circuits).
  A band edge is not perfectly sharp: an effect in one band can show a little in its neighbour.
- **Locking the primary band:** Peter calls band choice trial and error. Pick it from the test-run or pilot
  files, change `PRIMARY_BAND`, then write the date into `PRIMARY_LOCKED_ON` at the top of the script.
  The report prints a warning until this is filled in.
- **Sudden jumps.** In Peter's pilot, one sensor dropped to about 0.6x in 5-20 Hz at one moment while the other two
  stayed put. Subtracting the dummy only removes jumps that hit every channel. The report lists every lasting jump
  (at least 1.4x within an hour), says whether it was on one channel only and whether an event in the log explains it,
  and warns under the main result when a one-channel jump has no explanation. The robustness section also
  shows the result using medians, which jumps disturb less.
- **Temperature and humidity.** If the test and control bags changed differently (more than 1 degree or 10% humidity),
  the report warns: the signal may follow the climate, and with so few runs the regression cannot separate the two.
  The cleanest fix is to keep both bags in the same conditions, and to log the climate in every bag.
- **How many runs?** Run `python power_sim.py` (add `--pilot pilot_windows.csv` for a first guess from Peter's pilot).
  With only 2 runs the t-test has 1 degree of freedom and finds almost nothing; 3 or more is much better. Replace
  the guess with the real run-to-run variation after the first runs.
- **Mains hum:** the 50 Hz line and its harmonics (50, 100, 150 Hz, plus or minus 1.5 Hz) are cut out of every
  band in the frequency domain. The old option of also smoothing 400 Hz data with a moving average is off by
  default; turn it on with `--box-notch`.
- **The run is the unit, not the 5-minute bin.** Neighbouring bins are strongly correlated, so
  treating them as independent would give false confidence.
- **With 3 runs the test has little power.** Report the per-run values and the effect size,
  not only the p-value.

## Things to check on the first real data
- Look at `windows.csv` for the `flag` column. Many `saturated` bins mean a bad electrode setup.
- Check the plots: the dummy-corrected signal should be steady before the event.
- The dummy's own change (in the report) should be near 0.
- Old files (before 23 Oct 2026) are 100 Hz and already filtered on the board. The script
  reads the sample rate from each file's header, so bands above 45 Hz are skipped for those files.
- The code was tested only on the fake data above (an effect in all bands, an effect in 10-20 Hz only,
  and no effect), not on real recordings.
